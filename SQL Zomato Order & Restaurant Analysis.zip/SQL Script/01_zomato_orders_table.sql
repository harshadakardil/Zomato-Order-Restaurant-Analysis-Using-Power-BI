CREATE TABLE Zomato_Orders (
    order_id VARCHAR(20) PRIMARY KEY,
    restaurant_id VARCHAR(20),
    customer_id VARCHAR(20),
    order_date VARCHAR(20),
    order_time TIME,
    delivery_time INT,
    total_cost DECIMAL(10,2),
    item_count INT,
    payment_method VARCHAR(50),
    customer_rating DECIMAL(3,1)
);

SHOW CREATE TABLE Zomato_Orders;

SELECT * FROM Zomato_Orders;


ALTER TABLE Zomato_Restaurants
ADD PRIMARY KEY (restaurant_id);

ALTER TABLE Zomato_Orders
ADD PRIMARY KEY (order_id);

ALTER TABLE Zomato_Orders
ADD CONSTRAINT fk_restaurant
FOREIGN KEY (restaurant_id)
REFERENCES Zomato_Restaurants(restaurant_id);