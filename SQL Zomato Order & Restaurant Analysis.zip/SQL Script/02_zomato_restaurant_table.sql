CREATE TABLE Zomato_Restaurants (
    restaurant_id VARCHAR(20) PRIMARY KEY,
    restaurant_name VARCHAR(255),
    city VARCHAR(100),
    area VARCHAR(100),
    cuisine VARCHAR(100),
    avg_rating DECIMAL(3,1),
    total_ratings INT,
    price_range VARCHAR(20),
    delivery_available VARCHAR(10)
);



SHOW CREATE TABLE Zomato_Restaurants;

SELECT * FROM Zomato_Restaurants;
