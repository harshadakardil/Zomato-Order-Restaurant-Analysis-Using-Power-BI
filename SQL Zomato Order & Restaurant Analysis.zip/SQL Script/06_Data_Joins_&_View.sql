SELECT
    o.order_id,
    o.order_date,
    o.order_time,
    r.restaurant_name,
    r.city,
    r.area,
    r.cuisine,
    o.total_cost,
    o.item_count,
    o.payment_method,
    o.customer_rating,
    r.avg_rating,
    r.price_range,
    r.delivery_available
FROM Zomato_Orders o
JOIN Zomato_Restaurants r
ON o.restaurant_id = r.restaurant_id;


CREATE VIEW vw_Zomato_Analysis AS
SELECT
    o.order_id,
    o.restaurant_id,
    r.restaurant_name,
    r.city,
    r.area,
    r.cuisine,
    o.customer_id,
    o.order_date,
    o.order_time,
    o.delivery_time,
    o.total_cost,
    o.item_count,
    o.payment_method,
    o.customer_rating,
    r.avg_rating,
    r.total_ratings,
    r.price_range,
    r.delivery_available
FROM Zomato_Orders o
JOIN Zomato_Restaurants r
ON o.restaurant_id = r.restaurant_id;

SELECT * FROM vw_Zomato_Analysis;
