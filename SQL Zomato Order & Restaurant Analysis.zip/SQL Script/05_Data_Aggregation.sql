SELECT
    r.city,
    ROUND(AVG(o.total_cost),2) AS Average_Order_Value
FROM Zomato_Orders o
JOIN Zomato_Restaurants r
ON o.restaurant_id = r.restaurant_id
GROUP BY r.city
ORDER BY Average_Order_Value DESC;

SELECT
    r.restaurant_name,
    ROUND(SUM(o.total_cost),2) AS Total_Sales
FROM Zomato_Orders o
JOIN Zomato_Restaurants r
ON o.restaurant_id = r.restaurant_id
GROUP BY r.restaurant_name
ORDER BY Total_Sales DESC
LIMIT 5;

