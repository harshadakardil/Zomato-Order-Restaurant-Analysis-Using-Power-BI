SELECT
    city,
    COUNT(*) AS Total_Restaurants
FROM Zomato_Restaurants
GROUP BY city
ORDER BY Total_Restaurants DESC;

SELECT
    r.city,
    COUNT(o.order_id) AS Total_Orders
FROM Zomato_Orders o
JOIN Zomato_Restaurants r
ON o.restaurant_id = r.restaurant_id
GROUP BY r.city
ORDER BY Total_Orders DESC
LIMIT 5;

SELECT
    r.restaurant_name,
    ROUND(SUM(o.total_cost),2) AS Total_Revenue
FROM Zomato_Orders o
JOIN Zomato_Restaurants r
ON o.restaurant_id = r.restaurant_id
GROUP BY r.restaurant_name
ORDER BY Total_Revenue DESC;