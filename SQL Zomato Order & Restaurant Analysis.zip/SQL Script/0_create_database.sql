CREATE DATABASE ZomatoDB;

USE ZomatoDB;





