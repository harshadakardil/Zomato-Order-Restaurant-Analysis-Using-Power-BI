SELECT COUNT(*) AS Total_Orders
FROM Zomato_Orders;

SELECT order_id, COUNT(*) AS Duplicate_Count
FROM Zomato_Orders
GROUP BY order_id
HAVING COUNT(*) > 1;

SELECT
SUM(order_id IS NULL) AS order_id_null,
SUM(restaurant_id IS NULL) AS restaurant_id_null,
SUM(customer_id IS NULL) AS customer_id_null,
SUM(order_date IS NULL) AS order_date_null,
SUM(order_time IS NULL) AS order_time_null,
SUM(delivery_time IS NULL) AS delivery_time_null,
SUM(total_cost IS NULL) AS total_cost_null,
SUM(item_count IS NULL) AS item_count_null,
SUM(payment_method IS NULL) AS payment_method_null,
SUM(customer_rating IS NULL) AS customer_rating_null
FROM Zomato_Orders;


SELECT COUNT(*) AS Total_Restaurants
FROM Zomato_Restaurants;

SELECT restaurant_id, COUNT(*) AS Duplicate_Count
FROM Zomato_Restaurants
GROUP BY restaurant_id
HAVING COUNT(*) > 1;

SELECT
SUM(restaurant_id IS NULL) AS restaurant_id_null,
SUM(restaurant_name IS NULL) AS restaurant_name_null,
SUM(city IS NULL) AS city_null,
SUM(area IS NULL) AS area_null,
SUM(cuisine IS NULL) AS cuisine_null,
SUM(avg_rating IS NULL) AS avg_rating_null,
SUM(total_ratings IS NULL) AS total_ratings_null,
SUM(price_range IS NULL) AS price_range_null,
SUM(delivery_available IS NULL) AS delivery_available_null
FROM Zomato_Restaurants;



-- Remove extra spaces from payment method
UPDATE Zomato_Orders
SET payment_method = TRIM(payment_method);

-- Remove extra spaces from restaurant name
UPDATE Zomato_Restaurants
SET restaurant_name = TRIM(restaurant_name);

-- Remove extra spaces from city
UPDATE Zomato_Restaurants
SET city = TRIM(city);

-- Remove extra spaces from area
UPDATE Zomato_Restaurants
SET area = TRIM(area);

-- Standardize cuisine values
UPDATE Zomato_Restaurants
SET cuisine = TRIM(cuisine);

-- Verify cleaning

SELECT
payment_method,
COUNT(*)
FROM Zomato_Orders
GROUP BY payment_method;

SELECT
city,
COUNT(*)
FROM Zomato_Restaurants
GROUP BY city;